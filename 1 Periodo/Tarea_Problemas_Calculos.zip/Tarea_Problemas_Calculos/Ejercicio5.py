#Ejercicio 5.- Escriba un programa que imprima un número complejo, su parte real e imaginaria.

#Este programa imprimirá un número complejo, dandonos la parte real y su parte imaginaria por separadas
complejo = (56+26) + 90j

print(f'''El número complejo es igual a: {complejo}, 
la parte real es igual a: {complejo.real} y la parte imaginaria es igual a: {complejo.imag}''')
